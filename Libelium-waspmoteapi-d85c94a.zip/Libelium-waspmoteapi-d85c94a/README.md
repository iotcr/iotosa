### Waspmote API Repository
Download the last version of the Community code of the open source sensor platform Waspmote.

**Warning**: this branch of code is pending of approval and is meant to be used just for developers who want to share their modifications of the Waspmote API with community. The last version of the official (tested and stable) branch can be downloaded at:

* https://github.com/Libelium/waspmoteapi
* http://www.libelium.com/development/waspmote

Read more about the commit and approval code process at: 
* http://www.libelium.com/development/developers/
